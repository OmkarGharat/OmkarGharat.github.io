---
title: Introduction to My Digital Garden
date: 2026-02-01
description: The start of my personal blogging site using Docsify.
---

**Date:** Feb 1, 2026

Hello world! This is the start of my personal blogging site. I decided to use **Docsify** because it provides a clean, book-like reading experience without the need for a complex build process.

## Why Docsify?

- **No Build Steps**: It parses Markdown on the fly.
- **Lightweight**: Just an `index.html` and some JS.
- **The Book Feel**: Perfect for documentation and knowledge sharing.

Stay tuned for more updates!