---
title: API Testing Resources
date: 2026-02-03
description: Useful free resources for API testing and JSON schema validation.
---



## JSON Storage online free

[https://www.npoint.io](https://www.npoint.io/docs/991ac5d31ab3e9926800)

---

## JSON Schema available online free

[https://www.schemastore.org](https://www.schemastore.org/)

---

#### Note: use Gemini to generate Sample JSON from JSON Schema

---
